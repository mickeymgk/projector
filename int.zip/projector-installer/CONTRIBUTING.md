# Contributing to Projector
Thank you for reading this: we welcome any contributions.

All Projector-related projects have the same contributing guidelines. The place where they are described
is [documentation](https://jetbrains.github.io/projector-client/mkdocs/latest/about/contributing/).
